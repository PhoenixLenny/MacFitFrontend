import { ref, computed } from 'vue'
import api from './api'

// Shared state (module-level so it's consistent across the app)
const user = ref(null)
const loading = ref(false)
const error = ref(null)
const isAdmin = ref(false)

// Auto-restore from localStorage when the file is imported (fixes refresh issue)
const savedUser = localStorage.getItem('user')
const savedIsAdmin = localStorage.getItem('isAdmin')
if (savedUser) {
  user.value = JSON.parse(savedUser)
  isAdmin.value = savedIsAdmin === 'true'
}

export function useAuth() {
  const isAuthenticated = computed(() => !!user.value)

  // ==================== LOGIN ====================
  async function login(credentials) {
    loading.value = true
    error.value = null

    try {
      if (!credentials.email || !credentials.password) {
        throw new Error('Email and password are required')
      }

      const response = await api.post('login', credentials)
      const { token, user: userData } = response.data

      console.log('Login response:', response.data)

      if (token && userData) {
        user.value = userData
        isAdmin.value = user.value?.role === 1   // Fixed + safer

        localStorage.setItem('authToken', token)
        localStorage.setItem('user', JSON.stringify(user.value))
        localStorage.setItem('isAdmin', isAdmin.value.toString())

        console.log('User logged in:', user.value)
        return response
      } else {
        throw new Error('Invalid response format from server')
      }
    } catch (err) {
      error.value = err.response?.data?.message || err.message || 'Login failed'
      throw err
    } finally {
      loading.value = false
    }
  }

  // ==================== REGISTER ====================
  async function register(formData) {
    loading.value = true
    error.value = null

    try {
      const response = await api.post('register', formData)
      const { token, user: userData } = response.data

      if (token && userData) {
        user.value = userData
        isAdmin.value = user.value?.role === 1   // Added for consistency

        localStorage.setItem('authToken', token)
        localStorage.setItem('user', JSON.stringify(user.value))
        localStorage.setItem('isAdmin', isAdmin.value.toString())

        return response
      } else {
        throw new Error('Invalid response format from server')
      }
    } catch (err) {
      error.value = err.response?.data?.message || 'Registration failed'
      throw err
    } finally {
      loading.value = false
    }
  }

  // ==================== LOGOUT ====================
  function logout() {
    user.value = null
    isAdmin.value = false

    localStorage.removeItem('authToken')
    localStorage.removeItem('user')
    localStorage.removeItem('isAdmin')
  }

  return {
    user,
    loading,
    error,
    isAuthenticated,
    isAdmin,
    login,
    register,
    logout,
  }
}